package com.example.food_recipes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
